//
//  WeatherTableViewCell.swift
//  WeatherApplicatioIOSLevertKabe
//
//  Created by Reverside Software Solutions on 3/2/18.
//  Copyright © 2018 Reverside Software Solutions. All rights reserved.
//

import UIKit

class WeatherTableViewCell: UITableViewCell {

    @IBOutlet weak var dateTxt: UILabel!
    
    @IBOutlet weak var imageTxt: UIImageView!
    
    @IBOutlet weak var temperatureTxt: UILabel!
    
    @IBOutlet weak var descTxt: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
