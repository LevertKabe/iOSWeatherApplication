//
//  Location.swift
//  WeatherApplicatioIOSLevertKabe
//
//  Created by Reverside Software Solutions on 3/1/18.
//  Copyright © 2018 Reverside Software Solutions. All rights reserved.
//

import Foundation
import CoreLocation

struct Location {
    let name:String
    let icon:String
    let temperature:Double
    
    enum SerializationError:Error {
        case missing(String)
        case invalid(String, Any)
    }
    
    
    init(json:[String:Any]) throws {
        guard let summary = json["summary"] as? String else {throw SerializationError.missing("summary is missing")}
        
        guard let icon = json["icon"] as? String else {throw SerializationError.missing("icon is missing")}
        
        guard let temperature = json["temperatureMax"] as? Double else {throw SerializationError.missing("temp is missing")}
        
        self.name = summary
        self.icon = icon
        self.temperature = temperature
        
    }
    
    
    static var basePath = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location="
    
    static func forecast (withLocation location:CLLocationCoordinate2D, completion: @escaping ([Location]?) -> ()) {
        
        basePath = basePath + "\(location.latitude),\(location.longitude)" + "&radius=500&type=restaurant&keyword=cruise&key=YOUR_API_KEY"
        
        //let url = basePath
        let request = URLRequest(url: URL(string: basePath)!)
        var locationArray:[Location] = []
        
        guard let url = URL(string: basePath) else { print("URL is invalid"); return }
        //guard let url = URL(string: basePath) else { print("URL is invalid"); return }
        
        URLSession.shared.dataTask(with: url)
        {
            (data, response,err) in
            
            print(data)
            guard let data = data else{return}
            do
            {
                let location = try JSONDecoder().decode([Location].self, from: data )
                
                for i in 0 ... location.count - 1
                {
                    locationArray.append(location[i])
                }
            }
            catch let jsonErr
            {
                print(jsonErr)
            }
            completion(locationArray)
        }.resume()
}
}


